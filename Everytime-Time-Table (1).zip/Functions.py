####################################################
#   이외에 필요한 함수들을 정의합니다.(조합 결과 등)   #
####################################################

'''
TO DO LIST

* 함수를 만들기 전에 직접 에타앱을 들어가서 '시간표 마법사' 기능을 써보고 오기

* 필요한 함수가 무엇일지 여러가지 떠올려보고 제작

* GUI_by_tkinter.py 팀으로부터 함수 제작 요청이 있을 수 있음

* 밑에 적어둔 함수들은 그냥 생각난거만 적어본거!
'''



from random import shuffle, sample

def search_subject(name, yg, tg, gg, gicho, gj, ns, cs):
	




def combinations(groups):
	possible_time_table = [] # 가능한 조합


	# 10중 for문을 돌려야하지 않을까...(더 나은 아이디어 있으면 제안부탁)
  # 10중 for문이요...? - ㅇㅈ

	shuffle(possible_time_table)
	try:
		return sample(possible_time_table, 60)
	except:
		return possible_time_table

def 강의명또는교수명으로검색하는함수():
	return 데이터리스트

def 시간표분류선택하면분류보여주는함수(): # 함수 예시
	분류된데이터 = []


	기능구현


	return 분류된데이터