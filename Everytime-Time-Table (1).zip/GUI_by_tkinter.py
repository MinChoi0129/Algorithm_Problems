############################################
#   tkinter를 통해 GUI와 함수를 구성합니다   #
############################################

from tkinter import *
group_list=["Group1","Goup2","Group3","Group4","Group5","Group6","Group7","Group8","Group9","Group10"]
row_num=1
col_num=0

'''
TO DO LIST

* 버튼 클릭 시 함수가 동작하여 각 버튼에 따른 기능이 수행되어야 함
* 그런 함수는 Functions.py에서 import하여 사용

* 어떠어떠한 함수가 필요하다면 Functions.py 팀에게 함수를 요청(입출력을 상세히 알려주기)
* 간단한 함수인 경우 직접 Functions.py에서 제작

* 카톡에 보낸 디자인(대충 만든거임) 그대로 할 필요 없고 더 나은 디자인을 제안해주는 사람이 있다면 그 디자인대로 구현하면 좋겠음(디자인 변경은 빨리 이뤄질수록 좋겠지)
'''

#def search_by_name():
#	return

#def search_by_prof():
#	return


window=Tk()

sub_title=Label(window,text="Search subject",width=25,bg="green")
sub_title_1=Label(window,text="Lecture",width=25,bg="green")
search=Entry(window,bg = "pink",width=25)

#검색과 강의
sub_title.grid(row=1,column=0)
sub_title_1.grid(row=1,column=1)
search.grid(row=2,column=0)


for i in range(0,10):
    if i%2==0:
        col_num=2
        Label(window,text=group_list[i],width=25,bg="green").grid(row=row_num,column=col_num)
        for j in range(0,2):
            Label(window,text="",width=25,bg="orange").grid(row=row_num+1,column=col_num)
            row_num+=1 
    else:
        col_num=3
        Label(window,text=group_list[i],width=25,bg="green",).grid(row=row_num-2,column=col_num)
        for j in range(0,2):
            Label(window,text="",width=25,bg="orange").grid(row=row_num-1,column=col_num)
            row_num+=1


from tkinter import ttk
역교 = ["None", "Essential", "Choose"]
통교 = ["None", "Moonhak", "History_cheolhak", "Human_society", "science_kisool", "Art and Sports", "Fusion"]
개교 = ["None", "jinro_job", "changupsanhakcooper", "etc"]
기초 = ["None", "waoguka", "InmoonSahui ", "nature"]
교직 = ["None", "Gyogick"]
일반 = ["None", "Ilban_seontack"]
전공 = ["None", "Cs_pilsoo", "Cs_seontack"]

Label(window,text="Yeoklyang_G",width=23,bg="pink").grid(row = 3, column = 0)
cb1 = ttk.Combobox(window, width=23, height=10, values=역교)
cb1.grid(row = 4, column = 0)
cb1.set("Choose Option")


Label(window,text="Tonghab_G",width=23,bg="pink").grid(row = 5, column = 0)
cb2 = ttk.Combobox(window, width=23, height=10, values=통교)
cb2.grid(row = 6, column = 0)
cb2.set("Choose Option")


Label(window,text="Gaechuck_G",width=23,bg="pink").grid(row = 7, column = 0)
cb3 = ttk.Combobox(window, width=23, height=10, values=개교)
cb3.grid(row = 8, column = 0)
cb3.set("Choose Option")


Label(window,text="Gicho_G",width=23,bg="pink").grid(row = 9, column = 0)
cb4 = ttk.Combobox(window, width=23, height=10, values=기초)
cb4.grid(row = 10, column = 0)
cb4.set("Choose Option")


Label(window,text="Gyogick",width=23,bg="pink").grid(row = 11, column = 0)
cb5 = ttk.Combobox(window, width=23, height=10, values=교직)
cb5.grid(row = 12, column = 0)
cb5.set("Choose Option")


Label(window,text="Ilban_seontack",width=23,bg="pink").grid(row = 13, column = 0)
cb6 = ttk.Combobox(window, width=23, height=10, values=일반)
cb6.grid(row = 14, column = 0)
cb6.set("Choose Option")


Label(window,text="CS Jeongong",width=23,bg="pink").grid(row = 15, column = 0)
cb7 = ttk.Combobox(window, width=23, height=10, values=전공)
cb7.grid(row = 16, column = 0)
cb7.set("Choose Option")

Button(window, text = "Search").grid(row = 17, column = 0)


window.mainloop()