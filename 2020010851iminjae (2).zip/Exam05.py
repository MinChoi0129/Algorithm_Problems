from cs1graphics import * #수정금지
from math import sqrt

paper = Canvas( w=500, h=500, bgColor='white') #수정금지

#원안에 검은사각형, 흰사각형, 검은사각형
#math sqrt사용

circle = Circle(250, Point(250, 250))
circle.setFillColor("white")

square1 = Square(500 / sqrt(2), Point(250, 250))
square1.setFillColor("black")
square1.rotate(45)

square2 = Square(500 / sqrt(2) / sqrt(2), Point(250, 250))
square2.setFillColor("white")

square3 = Square(500 / sqrt(2) / sqrt(2) / sqrt(2), Point(250, 250))
square3.setFillColor("black")
square3.rotate(45)

paper.add(circle)
paper.add(square1)
paper.add(square2)
paper.add(square3)