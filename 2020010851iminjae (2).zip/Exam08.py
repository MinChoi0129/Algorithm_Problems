# 국가코드, 국가이름, 위도, 경도
# result.txt, 남반구만 출력

f = open("average-latitude-longitude-countries.csv", "r")
g = open("result.txt", "w")
f.readline()

while True:
	line = f.readline()
	if not line:
		break
	line_data = line.split(",")

	if len(line_data) == 4:
		if float(line_data[2]) < 0:
			g.write((line_data[1].strip('"')) + "\n")

	else:
		if float(line_data[3]) < 0:
			g.write((line_data[1].strip('"') + ',' + line_data[2].strip('"')) + "\n")

f.close()
g.close()