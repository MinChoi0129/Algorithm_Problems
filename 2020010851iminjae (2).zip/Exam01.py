from cs1robots import * #수정금지

create_world(5, 5) #수정금지

#hubo = Robot(avenue=5,street=1,orientation='N')
#hubo = Robot(avenue=5,street=1,orientation='E')
#hubo = Robot(avenue=1,street=5,orientation='N')
#hubo = Robot(avenue=1,street=5,orientation='W')
#hubo = Robot(avenue=3,street=3,orientation='N')
hubo = Robot(avenue=3,street=3,orientation='S')

hubo.set_trace('blue') #수정금지

while not hubo.facing_north():
	hubo.turn_left()

while hubo.front_is_clear():
	hubo.move()

hubo.turn_left()

while hubo.front_is_clear():
	hubo.move()

hubo.turn_left()

while hubo.front_is_clear():
	hubo.move()