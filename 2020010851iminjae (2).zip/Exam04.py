#len()만들기
#fibo(n) 만들기 n >= 2 정수

def length(iter):
	element_cnt = 0
	for element in iter:
		element_cnt += 1
	return element_cnt

def fibo(n): # n>=2
	fibo_nums = [0, 1]
	while len(fibo_nums) != n:
		fibo_nums.append(fibo_nums[-1] + fibo_nums[-2])
	return fibo_nums
