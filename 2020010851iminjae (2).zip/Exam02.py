from math import * #수정금지

# gunter처럼 별이랑 스페이스바 찍기

for degree in range(41):
	value = sin(radians(degree * 9))
	real = int((value + 1) * 41)
	print(" " * (real - 1), end = "")
	print("*")