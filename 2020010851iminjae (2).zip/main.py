#import Exam01
#import Exam02
#import Exam03

from Exam04 import *
print(length("abcde")) #5
print(length([3.14, "hello", 10])) #3
print(length((range(10)))) #10
print(fibo(2)) #[0, 1]
print(fibo(5)) #[0, 1, 1, 2, 3]
print(fibo(10)) #[0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

#import Exam05
#import Exam06
#import Exam07
#import Exam08