from cs1graphics import *  #수정금지
from time import sleep

paper = Canvas(w=500, h=500, bgColor='white') #수정금지

# 시계만들기
# 초침 제일 가까이 시침 제일 멀리
# 초분시 = RBG
# sleep(1)

circle = Circle(250, Point(250, 250))
circle.setFillColor("white")

secs = Rectangle(10, 250, Point(250, 0 + 250 / 2))
secs.setFillColor("red")
secs.adjustReference(0, 250 / 2)
mins = Rectangle(20, 200, Point(250, 50 + 200 / 2))
mins.setFillColor("blue")
mins.adjustReference(0, 200 / 2)
hours = Rectangle(30, 150, Point(250, 100 + 150 / 2))
hours.setFillColor("green")
hours.adjustReference(0, 150 / 2)

paper.add(circle)
paper.add(hours)
paper.add(mins)
paper.add(secs)

now = 0
while True:
	secs.rotate(6)
	now += 1

	if now % 60 == 0:
		mins.rotate(6)
	if now == 3600:
		hours.rotate(30)
		now = 0
	sleep(1)