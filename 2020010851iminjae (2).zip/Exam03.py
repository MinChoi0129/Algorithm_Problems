from math import * #수정금지

# gunter처럼 별이랑 스페이스바 찍기

for degree in range(41):
	value = sin(radians(degree * 9))
	# 0, 9, 18, ...(각) -> sin value[-1~1]
	
	real = int((value + 1) * 41) # 평행이동 [0~2]

	if real >= 41:
		for i in range(real):
			if i == 41:
				print("|", end = "")
			print(" " , end = "")
		print("*")

	else:
		for i in range(real):
			print(" ", end = "")
		print("*", end = "")
		for i in range(40 - real):
			print(" ", end = "")
		print("|")
		
		