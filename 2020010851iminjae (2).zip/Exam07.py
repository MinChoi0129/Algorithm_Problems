from cs1graphics import * #수정금지
from time import sleep #수정금지
from random import shuffle #수정금지

paper = Canvas(640,580,'white','Memento') #수정금지

path = "./images/" #수정금지
names = ("pororo.jpg","poby.jpg","loopy.jpg","harry.jpg","eddy.jpg","crong.jpg") #수정금지

# pdf참조, repl에서 내꺼 가져오기

cards = []
num_pads = []

class Card:
	def __init__(self, img, name, correct):
		self.img = img
		self.name = name
		self.correct = correct

tries = 1

def initialize():    
    for i in range(6):
        for k in range(4):
            cards.append(Card(Image(path+names[i]), names[i], False))
            
    shuffle(cards)
    
    for i in range(24):
        card = Layer()
        rect = Rectangle(90,120,Point(0,0))
        text = Text(str(i),18,Point(0,0))
        card.add(rect)
        card.add(text)
        num_pads.append(card)

def print_cards():
    paper.clear()
    w = 0
    h = 0
    i_w = 70
    i_h = 90
    for i in range(len(cards)):
        if cards[i].correct:
            cards[i].img.moveTo(i_w + w, i_h+h)
            paper.add(cards[i].img)
        else:
            num_pads[i].moveTo(i_w + w, i_h+h)
            paper.add(num_pads[i])
            
        w += 100
        if w % 600 == 0:
            w = 0
            h += 130

def first_time_show():
	paper.clear()
	w = 0
	h = 0
	i_w = 70
	i_h = 90
	for i in range(len(cards)):
		cards[i].img.moveTo(i_w + w, i_h + h)
		paper.add(cards[i].img)
		w += 100
		if w % 600 == 0:
			w = 0
			h += 130
	sleep(2)
         
def is_valid_num1(num1):
	vld_nums = [i for i in range(24)]
	if num1 not in vld_nums:
		return False
	if cards[num1].correct:
		return False
	return True

def is_valid_num2(num1, num2):
	vld_nums = [i for i in range(24)]
	if num2 not in vld_nums:
		return False
	if num1 == num2:
		return False
	if cards[num2].correct:
		return False

	return True

def check(num1,num2):
	
	if cards[num1].name != cards[num2].name:
		cards[num1].correct = False
		cards[num2].correct = False
		print_cards()
		return False
	
	return True
    

initialize()
first_time_show()
print_cards()
print ("### Welcome to the Python Memento game!!! ###")
while True:
	all_correct = True
	correct_cnt = 0
	for card in cards:
		if not card.correct:
			all_correct = False
		else:
			correct_cnt += 1
	if all_correct:
		break

	print (str(tries) + "th try. You got "+str(correct_cnt//2)+" pairs.")
	while True:
		num1 = int(input("Enter the first number : "))
		if not is_valid_num1(num1):
			continue
		else:
			break
	cards[num1].correct = True
	print_cards()

	while True:
		num2 = int(input("Enter the second number : "))
		if not is_valid_num2(num1, num2):
			continue
		else:
			break
	cards[num2].correct = True
	print_cards()
	sleep(1.5)

	tries += 1
	if check(num1,num2):
		print ("Correct!")
	else:
		print ("Wrong!")